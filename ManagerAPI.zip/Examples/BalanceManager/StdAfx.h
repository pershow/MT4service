//+------------------------------------------------------------------+
//|                                  MetaTrader 4 Manager API Sample |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once

#define WINVER         0x0501
#define _WIN32_IE      0x0600
#define VC_EXTRALEAN

#include <afxwin.h>
#include <afxext.h>
#include <afxdtctl.h>

#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>
#endif

#include <afxsock.h>
//+------------------------------------------------------------------+
